$('.allWrapper').css('background-color','#212121')
$('.notification_link').css('background-color','#313131')